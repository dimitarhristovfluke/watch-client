import React from "react";

export class NotFound extends React.Component {
  render() {
    return "Page not found...";
  }
}
