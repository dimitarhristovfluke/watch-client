const config = {
  dateTimeFormat: "MM/DD/YYYY HH:mm:ss",
  port: 8888,
  serverZoneOffset: 60
};

export default config;
